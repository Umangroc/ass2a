import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/dataService/data.service';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.scss']
})
export class SortComponent implements OnInit {

  view: any = "high";

  constructor(private dataSvc: DataService) { }

  ngOnInit() {
    this.sort(this.view);
  }

  sort(option){
    this.view = option;
    this.dataSvc.changeSortOption(this.view);
  }

}
