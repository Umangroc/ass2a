export class User
{
    id :"string";
    price: number;

}